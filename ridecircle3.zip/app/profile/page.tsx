import { TuroStyleProfile } from "@/components/profile/turo-style-profile"

export default function ProfilePage() {
  return (
    <div className="min-h-screen bg-slate-900">
      <TuroStyleProfile />
    </div>
  )
}
