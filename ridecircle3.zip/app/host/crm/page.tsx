import { EnhancedCRM } from "@/components/host/enhanced-crm"

export default function HostCRMPage() {
  return <EnhancedCRM />
}
